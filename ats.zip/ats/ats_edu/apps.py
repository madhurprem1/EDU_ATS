from django.apps import AppConfig


class AtsEduConfig(AppConfig):
    name = 'ats_edu'
